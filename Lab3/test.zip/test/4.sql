.headers on
SELECT /*count(*) AS*/ s_name
FROM supplier
WHERE s_acctbal > 8000;